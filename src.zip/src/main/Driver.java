package main;

import java.io.IOException;

public class Driver {
	public static void main(String[] args) throws IOException {
		String filename = "a_example";
		PizzaSlicer ps = new PizzaSlicer(filename + ".in");
		System.out.println("Rows: " + ps.getRow());
		System.out.println("Columns: " + ps.getColumn());
		System.out.println("MI: " + ps.getMinIngredient());
		System.out.println("MC: " + ps.getMaxCells());
		System.out.println(ps.printPizza());
		ps.cutPizza();
		for (Slice s : ps.getSlices()) {
			System.out.println(s);
		}
		ps.writeSlices(filename + ".submission");
	}
}
